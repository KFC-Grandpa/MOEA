function AEAD(Global)
% <algorithm> <A>
% type --- 1 --- Type of operator (1. DE 2. GA)
    type = Global.ParameterSet(1);
    %% Generate random population
    Population1 = Global.Initialization();
    Population2 = Global.Initialization();
    Fitness1    = CalFitness(Population1.objs,Population1.cons,0);
    Fitness2    = CalFitness(Population2.objs,Population2.cons,1e6);
    
    min_epsilon      = 1e-4;
    change_threshold = 1e-2;
    max_change       = 1;
    epsilon_k        = 1e8;
    tao              = 0.05;
    max_ep           = 0;
    gen              = 1;
    stage = false;
    
    %% Optimization
    while Global.NotTermination(Population1)
        pop_cons2                   = Population2.cons;
        cv2                        = overall_cv(pop_cons2);
        population                 = [Population2.decs,Population2.objs,cv2];
        Objvalues(gen)             = sum(sum(Population2.objs,1));
        ep(gen)                    =  epsilon_k;
        if type == 1
            MatingPool1 = TournamentSelection(2,2*Global.N,Fitness1);
            MatingPool2 = TournamentSelection(2,2*Global.N,Fitness2);
            Offspring1  = DE(Population1,Population1(MatingPool1(1:end/2)),Population1(MatingPool1(end/2+1:end)));
            Offspring2  = DE(Population2,Population2(MatingPool2(1:end/2)),Population2(MatingPool2(end/2+1:end)));
        elseif type == 2
            MatingPool1 = TournamentSelection(2,Global.N,Fitness1);
            MatingPool2 = TournamentSelection(2,Global.N,Fitness2);
            Offspring1  = GAhalf(Population1(MatingPool1));
            Offspring2  = GAhalf(Population2(MatingPool2));
        end
        %% 侦测Pop2是否收敛
        [FrontNo2,~]=NDSort(Population2.objs,size(Population2.objs,1));
        NC2=size(find(FrontNo2==1),2);
        if gen ~= 1
            max_change = abs(Objvalues(gen)-Objvalues(gen-1));
        end
        
        if max_change <= change_threshold &&NC2 == Global.N && stage == false
            epsilon_k = max(population(:,end),[],1);
            stage = true;
        end
        %% 产生Off3
        Offspring3 = [];
        if stage == true
            if type == 1
            Offspring3 = DE(Population1,Population2(MatingPool2(1:end/2)),Population2(MatingPool2(end/2+1:end)));
            elseif type == 2
                for i=1:Global.N/2
                    Offtemp = GAhalf([Population1(MatingPool1(i)),Population2(MatingPool2(i))]);
                    Offspring3 = [Offspring3,Offtemp];
                end
            end
        end
        %% 更新ep，maxep
        if stage == true
            [stage,epsilon_k] =  update_epsilon(stage,tao,epsilon_k,max_ep,min_epsilon); 
        end
        
        if epsilon_k < 9e5
            max_ep = max(max_ep,epsilon_k);
        end
        %% 环境选择产生新种群
        [Population1,Fitness1] = EnvironmentalSelection([Population1,Offspring1,Offspring2,Offspring3],Global.N,true,0);
        [Population2,Fitness2] = EnvironmentalSelection([Population2,Offspring2],Global.N,false,epsilon_k);
        gen = gen+1;
    end
end

function result = overall_cv(cv)
cv(cv <= 0) = 0;cv = abs(cv);
result = sum(cv,2);
end


function [stage,result] = update_epsilon(stage,tao,epsilon_k,epsilon_0,min_epsilon)
    if epsilon_k > min_epsilon
        result = (1 - tao) * epsilon_k; %逐渐变小
        stage = true;
    else
        result = epsilon_0;
        stage = false;
    end
end
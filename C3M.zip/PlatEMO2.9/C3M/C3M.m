function C3M(Global)
% <algorithm> <C>
% type --- 1 --- Type of operator (1. DE 2. GA)
    %% Generate random population
    type = Global.ParameterSet(1);
    processcon = 0;
    Population = Global.Initialization();
    totalcon = size(Population(1,1).con,2);
    Fitness    = CalFitness(Population.objs); 
    arch = [];
    gen = 2;
    Pops = [];
    change_threshold = 1e-3;
    for i = 1:totalcon
        Pops{1,i} = Population;
        Pops{2,i} = CalFitness(Population.objs,Population.cons,i);
        Pops{3,i} = i;
        Pops{4,i} = 0;
    end
    Objvalues(1) = sum(sum(Population.objs,1));
    ns = 0;
    flag = 1;
    state = 0;
    seq = [];
    index = 1;
    processed = [];
    %% Optimization
    while Global.NotTermination(Population) 
       % Reinitialization after stage transition
       if processcon <= totalcon
           if ns
               ns = 0;
               Population = Global.Initialization();
               Fitness    = CalFitness(Population.objs,Population.cons,processcon);
           end
       end
       
       % stage2 -> stage3
       if  flag && processcon > totalcon
           AllPops = [];
          for j = 1:size(Pops,2)
              AllPops = [AllPops,Pops{1,j}];
          end
           flag = 0;
           Population = EnvironmentalSelection([arch,AllPops,Population],Global.N,processcon,totalcon);
       end
       Objvalues(gen) = sum(sum(abs(Population.objs),1));
       
       % Reproduction
       if type == 1
            MatingPool = TournamentSelection(2,2*Global.N,Fitness);
            Offspring  = DE(Population,Population(MatingPool(1:end/2)),Population(MatingPool(end/2+1:end)));
       elseif type == 2
           MatingPool = TournamentSelection(2,Global.N,Fitness);
            Offspring  = GAhalf(Population(MatingPool));
       end
       
       % EnvironmentalSelection
        if flag
           for i = 1:totalcon
                [Pops{1,i},Pops{2,i}] = EnvironmentalSelection([Pops{1,i},Offspring],Global.N,i,totalcon);
           end
        end
       [Population,Fitness] = EnvironmentalSelection([Population,Offspring],Global.N,processcon,totalcon);
       
       % Update state of Population
       if gen > constant && processcon <=totalcon
            state = is_stable(Objvalues,gen,Population,Global.N,change_threshold,Global.M);
       end
       AllPops = [];
       for j = 1:size(Pops,2)
           AllPops = [AllPops,Pops{1,j}];
       end
       
       % Judge Type B relationship
      if state && processcon <=totalcon
          ns = 1;
          AllPops = [];
          for j = 1:size(Pops,2)
              AllPops = [AllPops,Pops{1,j}];
          end
          [FrontNo,~] = NDSort(AllPops.objs,inf);
          if processcon == 0
              ranks = [];
              for j = 1:size(Pops,2)
                  minF = min(FrontNo((j-1)*Global.N+1:j*Global.N));
                  ranks = [ranks,minF];
              end
              [~,seq] = sort(ranks);
              seq = fliplr(seq);
          else
              processed = [processed,processcon];
              Pops{4,processcon} = 1;
               Minindex = min(FrontNo((processcon-1)*Global.N+1:processcon*Global.N));
               for i = 1:size(Pops,2)
                   if i ~= processcon
                       maxindex = max(FrontNo((i-1)*Global.N+1:i*Global.N));
                        if maxindex <= Minindex
                            Pops{4,i} = 1;
                        end
                   end
               end
          end
          unpro = 0;
          for i = 1:size(Pops,2)
              unpro = unpro+Pops{4,i};
          end
          if unpro < totalcon
              while Pops{4,seq(index)} == 1
                  index = index + 1;
              end
              processcon = seq(index);
          else
              processcon = totalcon + 1;
          end
      end
      
      % Force to stage3
      if Global.evaluated ==  Global.evaluation * 0.7
          processcon = totalcon+1;
      end
      
       % Update archive
       if flag
           arch = EnvironmentalSelection1([arch,Population,Offspring],Global.N);
       else
           arch = Population;
       end
       gen = gen+1;
    end
end


function result = is_stable(Objvalues,gen,Population,N,change_threshold,M)
    result = 0;
    [FrontNo,~]=NDSort(Population.objs,size(Population.objs,1));
    NC=size(find(FrontNo==1),2);
    max_change = abs(Objvalues(gen)-Objvalues(gen-1));
    if NC == N 
         change_threshold = change_threshold * abs(((Objvalues(gen) / N))/(M))*10^(M-2);
        if max_change <= change_threshold
            result = 1;
        end
    end
end